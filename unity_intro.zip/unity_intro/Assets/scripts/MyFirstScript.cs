﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyFirstScript : MonoBehaviour
{
    [SerializeField] private int _newInt = 1;
    [SerializeField] private Vector2 _moveinput;
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("start");
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log("update");
        _moveinput = new Vector2(Input.GetAxis("Horizontal"),Input.GetAxis("Vertical"));      
    }

    private void FixedUpdate()
    {
        //Debug.Log("fixed update");
        transform.position += new Vector3(_moveinput.x * 0.2f, 0.0f, _moveinput.y * 0.2f);
    }
}
