﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //ship acceleration
    [SerializeField] private float _acceleration = 4.0f;
    private float _input;

    private Rigidbody2D _rigidbody; // rigidbody component
    private void Start()//called when the object is created
    {
        //get the component
        _rigidbody = GetComponent<Rigidbody2D>();
    }
    private void Update()//updates every frame
    {
        _input = Input.GetAxis("Horizontal"); //between -1 and 1
    }
    private void FixedUpdate()// updates 50 times per second
    {
        //movement force
        Vector2 moveForce = new Vector2( _acceleration * _input, 0.0f);
        //add movement to the rigidbody
        _rigidbody.AddForce(moveForce);
    }
}
