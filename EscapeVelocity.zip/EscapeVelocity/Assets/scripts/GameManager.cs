﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField] private float _gamespeed = 2.0f;
    [SerializeField] private float _speedincrease = 0.01f;
    
    [Header("Asteroids spawning")]
    [SerializeField] private float _asteroidSpawnDistance = 1.0f;
    [SerializeField] private Rigidbody2D[] _asteroidPrefabs;
    [SerializeField] private float _spawnTime = 1.0f;

    private float _lastAsteroidDistance;
    private float _totalDistance;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //increase game speed
        _gamespeed += _speedincrease * Time.deltaTime;
        //add to total distance
        _totalDistance += _gamespeed * Time.deltaTime;
        //check if we hav to spawn an asteroid
        if(_totalDistance > _lastAsteroidDistance + _asteroidSpawnDistance)
        {
            //set spawn distance
            _lastAsteroidDistance = _totalDistance;
            //select a random asteroid prefab
            Rigidbody2D selectAsteroidPrefab = _asteroidPrefabs[Random.Range(0, _asteroidPrefabs.Length)];
            //set random position
            Vector3 spawnPosition = transform.position + new Vector3(Random.Range(-_asteroidSpawnDistance, _asteroidSpawnDistance), 0f,0f);
            //initializate the selected prefab
            Rigidbody2D spawnedAsteroid = Instantiate(selectAsteroidPrefab);
            spawnedAsteroid.transform.position = spawnPosition;
            spawnedAsteroid.velocity = new Vector2(0.0f, -_gamespeed);
        }
    }
}
