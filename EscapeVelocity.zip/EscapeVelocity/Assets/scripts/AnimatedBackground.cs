﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#pragma warning disable 649

public class AnimatedBackground : MonoBehaviour
{
    //scroll
    [SerializeField] private Vector2 _scrollspeed;

    private Material _backgroundMaterial;

    private void Start()
    {
        _backgroundMaterial = GetComponent<MeshRenderer>().material;
    }
    private void Update()
    {
        _backgroundMaterial.mainTextureOffset += _scrollspeed * Time.deltaTime;

        //time.deltatime: how long took to update the previous frame
    }

}
